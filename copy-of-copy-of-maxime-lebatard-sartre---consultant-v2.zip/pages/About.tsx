import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Award, Briefcase, MapPin } from 'lucide-react';
import { SKILLS, EXPERIENCE_DATA, CERTIFICATIONS, PROFILE_IMAGE } from '../constants';

const About: React.FC = () => {
  return (
    <div className="pt-24 pb-20 overflow-hidden">
      
      {/* HEADER / INTRO */}
      <section className="max-w-7xl mx-auto px-6 mb-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            
            {/* Image Column */}
            <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
                className="relative order-2 lg:order-1"
            >
                <div className="relative aspect-[4/5] md:aspect-square lg:aspect-[4/5] rounded-[2.5rem] overflow-hidden shadow-2xl group">
                    <img 
                        src={PROFILE_IMAGE} 
                        alt="Maxime Lebatard-Sartre" 
                        className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 ease-in-out scale-105 group-hover:scale-100"
                    />
                    <div className="absolute inset-0 ring-1 ring-inset ring-black/10 rounded-[2.5rem]"></div>
                </div>
                {/* Decorative Element */}
                <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-100/50 rounded-full blur-2xl -z-10"></div>
                <div className="absolute -top-10 -left-10 w-40 h-40 bg-purple-100/50 rounded-full blur-2xl -z-10"></div>
            </motion.div>

            {/* Text Column */}
            <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="order-1 lg:order-2 space-y-8"
            >
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100 text-gray-600 text-xs font-semibold uppercase tracking-wider">
                    <MapPin size={12} /> Basé à Paris, opère Monde
                </div>
                
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold leading-[1.1]">
                    De la stratégie à l'exécution opérationnelle.
                </h1>
                
                <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
                    <p>
                        Je m’appelle <span className="text-black font-semibold">Maxime Lebatard-Sartre</span>. Je ne suis pas juste un consultant technique, je suis un architecte d'opérations.
                    </p>
                    <p>
                        Mon parcours est hybride par essence. J'ai été forgé par l'exigence des grands groupes internationaux chez <strong className="text-black">Paramount Global</strong>, où la rigueur et l'analyse de données sont reines. En parallèle, j'ai embrassé le chaos créatif et la nécessité de résultat immédiat de l'écosystème <strong className="text-black">Esport & Startup</strong>.
                    </p>
                    <p className="border-l-4 border-black pl-6 italic text-gray-800">
                        "Je conçois des systèmes qui permettent aux humains de se concentrer sur leur valeur ajoutée, en laissant les machines gérer le reste."
                    </p>
                    <p>
                        Aujourd'hui, je mets cette double culture au service des entreprises francophones qui souhaitent se moderniser. J'audite, je structure, et j'automatise. Pas de jargon inutile, juste des résultats : plus de temps, plus de marge, plus de clarté.
                    </p>
                </div>
            </motion.div>
        </div>
      </section>

      {/* SKILLS */}
      <section className="bg-surface py-20 mb-20">
        <div className="max-w-7xl mx-auto px-6">
            <h2 className="text-2xl font-display font-bold mb-10">Expertises Techniques & Stratégiques</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                {SKILLS.map((skill, idx) => (
                    <motion.div 
                        key={idx}
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.05 }}
                        className="bg-white p-5 rounded-xl border border-gray-100 flex items-center gap-3 shadow-sm hover:shadow-md transition-shadow group"
                    >
                        <CheckCircle2 size={20} className="text-gray-400 group-hover:text-blue-600 transition-colors flex-shrink-0" />
                        <span className="font-medium text-sm text-gray-700 group-hover:text-black transition-colors">{skill}</span>
                    </motion.div>
                ))}
            </div>
        </div>
      </section>

      {/* TIMELINE EXPERIENCE */}
      <section className="max-w-5xl mx-auto px-6 mb-24">
        <div className="flex items-center gap-3 mb-12">
            <Briefcase className="text-black" />
            <h2 className="text-3xl font-display font-bold">Parcours</h2>
        </div>
        
        <div className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-gray-300 before:to-transparent">
            {EXPERIENCE_DATA.map((exp, index) => (
                <div key={exp.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                    
                    {/* Icon */}
                    <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-gray-100 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 transition-colors group-hover:bg-black group-hover:border-black">
                        <div className="w-3 h-3 bg-gray-400 rounded-full group-hover:bg-white transition-colors"></div>
                    </div>
                    
                    {/* Content Card */}
                    <motion.div 
                        initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:border-blue-100 transition-all duration-300"
                    >
                        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                            <h3 className="font-bold text-xl text-black">{exp.company}</h3>
                            <time className="font-mono text-xs text-gray-500 uppercase tracking-wide bg-gray-50 px-2 py-1 rounded">{exp.period}</time>
                        </div>
                        <div className="font-medium text-blue-600 mb-4 text-sm uppercase tracking-wide">{exp.role}</div>
                        <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                            {exp.description}
                        </p>
                        {exp.missions && (
                            <ul className="space-y-3">
                                {exp.missions.map((m, i) => (
                                    <li key={i} className="text-xs text-gray-500 flex items-start gap-3">
                                        <span className="mt-1.5 w-1 h-1 bg-blue-500 rounded-full flex-shrink-0"></span>
                                        <span className="leading-relaxed">{m}</span>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </motion.div>
                </div>
            ))}
        </div>
      </section>

      {/* CERTIFICATIONS */}
      <section className="bg-neutral-950 text-white py-24 rounded-t-[3rem] -mb-20">
         <div className="max-w-7xl mx-auto px-6">
            <div className="flex items-center gap-3 mb-16">
                <Award className="text-blue-500" />
                <h2 className="text-3xl font-display font-bold">Certifications & Formation</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {CERTIFICATIONS.map((cert, idx) => (
                    <div key={idx} className="bg-white/5 border border-white/5 p-8 rounded-2xl hover:bg-white/10 transition-colors group cursor-default">
                        <div className="text-xs text-blue-400 mb-2 font-mono uppercase tracking-wider">{cert.issuer}</div>
                        <h4 className="font-bold text-lg mb-2 group-hover:text-blue-100 transition-colors">{cert.name}</h4>
                        <div className="text-sm text-gray-500">Obtenu en {cert.date}</div>
                    </div>
                ))}
            </div>
         </div>
      </section>

    </div>
  );
};

export default About;