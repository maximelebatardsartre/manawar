import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Copy, Check, Globe2 } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(CONTACT_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-[#f5f5f5] flex items-center justify-center relative overflow-hidden">
        
        {/* Abstract Background */}
        <div className="absolute inset-0 overflow-hidden">
             <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-blue-200/40 rounded-full mix-blend-multiply filter blur-[120px] animate-blob" />
             <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-purple-200/40 rounded-full mix-blend-multiply filter blur-[120px] animate-blob animation-delay-2000" />
        </div>

      <div className="max-w-4xl mx-auto px-6 relative z-10 w-full text-center">
        
        <motion.div
             initial={{ opacity: 0, y: 30 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ duration: 0.8 }}
             className="space-y-12"
        >
            <div className="space-y-6">
                <span className="inline-block px-4 py-1.5 rounded-full bg-white border border-gray-200 text-sm font-medium text-gray-600 shadow-sm">
                    Disponible pour de nouveaux projets
                </span>
                <h1 className="text-5xl md:text-7xl font-display font-bold leading-tight tracking-tight">
                    Travaillons<br/>ensemble.
                </h1>
                <p className="text-xl text-gray-600 font-light max-w-lg mx-auto">
                    Optimisation, Outils, IA. <br/>
                    Je transforme vos défis opérationnels en avantages compétitifs.
                </p>
            </div>

            {/* Email Action */}
            <div className="flex flex-col items-center gap-8">
                <motion.button 
                    onClick={handleCopy}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="group relative bg-white px-8 py-6 md:px-12 md:py-8 rounded-3xl shadow-xl border border-gray-100 flex items-center gap-4 md:gap-8 transition-all hover:shadow-2xl hover:border-blue-100"
                    data-cursor-hover
                >
                    <div className="bg-gray-50 p-4 rounded-2xl group-hover:bg-blue-50 transition-colors">
                        <Mail size={32} className="text-gray-900 group-hover:text-blue-600 transition-colors" />
                    </div>
                    <div className="text-left">
                        <div className="text-sm text-gray-400 font-medium mb-1">Email professionnel</div>
                        <div className="text-lg md:text-2xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                            {CONTACT_INFO.email}
                        </div>
                    </div>
                    <div className="absolute top-4 right-4 md:top-auto md:right-8 opacity-0 group-hover:opacity-100 transition-opacity">
                         {copied ? <Check className="text-green-500" /> : <Copy className="text-gray-400" />}
                    </div>
                    {copied && (
                        <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-black text-white text-xs px-3 py-1.5 rounded-lg">
                            Copié !
                        </div>
                    )}
                </motion.button>

                <div className="flex flex-col items-center gap-3 text-gray-500 mt-8">
                    <Globe2 size={24} className="text-blue-600 animate-pulse" />
                    <p className="text-lg font-medium">J'interviens partout dans la Francophonie.</p>
                    <p className="text-sm opacity-60">Paris • Bruxelles • Genève • Montréal • Remote</p>
                </div>
            </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Contact;