import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { Settings, MousePointerClick, Brain, Users } from 'lucide-react';

const Services: React.FC = () => {
  const servicesList = [
    {
      icon: Settings,
      title: "Optimisation & Structuration",
      category: "Processus Internes",
      description: "Audit, simplification, documentation et standardisation. Je vous aide à mettre en place des workflows clairs, efficaces et évolutifs.",
      features: ["Audit de l'existant", "Mapping des processus (BPMN)", "Création de documentation (SOP)", "Standardisation des méthodes"]
    },
    {
      icon: MousePointerClick,
      title: "Outils & Automatisation",
      category: "Intégration Digitale",
      description: "Je mets en place ou optimise vos outils internes : Notion, CRM, tableurs, automatisations API, dashboards. Objectif : réduire les tâches manuelles et fiabiliser vos opérations.",
      features: ["Setup Notion / Airtable", "Implémentation CRM (HubSpot)", "Automatisations (Make/Zapier)", "Tableaux de bord KPI"]
    },
    {
      icon: Brain,
      title: "Solutions IA",
      category: "Innovation Opérationnelle",
      description: "Création d’agents IA internes, automatisation intelligente, outils personnalisés et workflows augmentés par IA. L'IA devient un levier quotidien pour votre équipe.",
      features: ["Agents conversationnels internes", "Génération de contenu automatisée", "Analyse de données par IA", "Formation des équipes à l'IA"]
    },
    {
      icon: Users,
      title: "Coordination & Organisation",
      category: "Support Opérationnel",
      description: "Organisation d’événements, gestion de flux, encadrement d’équipes, communication terrain. Expertise issue de plusieurs années d’expérience opérationnelle.",
      features: ["Logistique événementielle", "Gestion d'équipes terrain", "Planification de projets", "Gestion de flux (personnes/data)"]
    }
  ];

  return (
    <div className="pt-24 pb-20">
      
      {/* HERO */}
      <section className="max-w-7xl mx-auto px-6 mb-24 text-center">
        <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
        >
            <h1 className="text-4xl md:text-6xl font-display font-bold mb-6">
                Des services simples, efficaces et <br/><span className="text-blue-600">orientés résultats.</span>
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
                Chaque mission est personnalisée selon vos objectifs, vos outils et votre maturité digitale.
                Je combine optimisation, automatisation et IA pour vous aider à gagner du temps.
            </p>
        </motion.div>
      </section>

      {/* SERVICE CARDS */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 gap-12">
            {servicesList.map((service, index) => (
                <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex flex-col md:flex-row gap-8 md:gap-16 items-start p-8 md:p-12 rounded-3xl bg-surface border border-gray-100 hover:bg-white hover:shadow-xl transition-all duration-300"
                >
                    <div className="w-16 h-16 bg-black text-white rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                        <service.icon size={32} strokeWidth={1.5} />
                    </div>
                    
                    <div className="flex-1">
                        <div className="text-blue-600 font-semibold tracking-wide uppercase text-xs mb-2">{service.category}</div>
                        <h2 className="text-3xl font-display font-bold mb-6">{service.title}</h2>
                        <p className="text-gray-600 text-lg leading-relaxed mb-8">
                            {service.description}
                        </p>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {service.features.map((feature, fIdx) => (
                                <div key={fIdx} className="flex items-center gap-3 text-sm font-medium text-gray-700">
                                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                                    {feature}
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="md:self-end w-full md:w-auto mt-6 md:mt-0">
                        <Link to="/contact">
                            <button className="w-full md:w-auto px-6 py-3 rounded-xl border border-gray-300 hover:border-black hover:bg-black hover:text-white transition-all text-sm font-semibold">
                                Demander un devis
                            </button>
                        </Link>
                    </div>
                </motion.div>
            ))}
        </div>
      </section>

      <section className="mt-24 text-center">
        <h3 className="text-2xl font-bold mb-8">Besoin d'une solution sur mesure ?</h3>
        <Link to="/contact">
            <Button>Discutons de votre projet</Button>
        </Link>
      </section>

    </div>
  );
};

export default Services;