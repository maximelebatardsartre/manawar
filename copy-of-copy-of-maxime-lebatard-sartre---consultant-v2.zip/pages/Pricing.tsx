import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Button from '../components/Button';
import { PRICING_DATA } from '../constants';
import { Check } from 'lucide-react';

const Pricing: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-surface min-h-screen">
      
      <section className="max-w-4xl mx-auto px-6 text-center mb-16">
        <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
        >
            <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">Tarifs Journaliers</h1>
            <p className="text-gray-600 text-lg">
                Transparence et flexibilité. Les tarifs varient selon la complexité, la durée et le périmètre de la mission.
            </p>
        </motion.div>
      </section>

      <section className="max-w-5xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PRICING_DATA.map((item, index) => (
                <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className={`relative p-8 rounded-2xl bg-white border ${index === 1 ? 'border-blue-500 shadow-xl ring-1 ring-blue-500' : 'border-gray-200 shadow-sm'} flex flex-col`}
                >
                    {index === 1 && (
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                            Populaire
                        </div>
                    )}
                    <h3 className="text-lg font-bold mb-4">{item.service}</h3>
                    <div className="text-3xl font-display font-bold mb-6 text-gray-900 tracking-tight">
                        {item.price.split('/')[0]} <span className="text-sm font-normal text-gray-500">/ jour</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-8 flex-grow">
                        {item.description}
                    </p>
                    <ul className="space-y-4 mb-8">
                        <li className="flex items-start gap-3 text-sm text-gray-700">
                            <Check size={16} className="text-green-500 mt-0.5 shrink-0" />
                            <span>Accompagnement personnalisé</span>
                        </li>
                        <li className="flex items-start gap-3 text-sm text-gray-700">
                            <Check size={16} className="text-green-500 mt-0.5 shrink-0" />
                            <span>Suivi et reporting</span>
                        </li>
                    </ul>
                    <Link to="/contact" className="mt-auto">
                        <button className={`w-full py-3 rounded-lg font-semibold text-sm transition-colors ${index === 1 ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}>
                            Demander un devis
                        </button>
                    </Link>
                </motion.div>
            ))}
        </div>

        <div className="mt-16 text-center max-w-2xl mx-auto bg-white p-8 rounded-2xl border border-gray-100 shadow-sm">
            <h4 className="font-bold text-lg mb-2">Un projet spécifique ?</h4>
            <p className="text-gray-600 mb-6 text-sm">
                Pour des missions longues durées ou des projets forfaitaires, contactez-moi pour une proposition adaptée.
            </p>
            <Link to="/contact">
                <Button variant="outline" className="text-black border-gray-300 hover:bg-gray-50">Demander un devis personnalisé</Button>
            </Link>
        </div>
      </section>

    </div>
  );
};

export default Pricing;