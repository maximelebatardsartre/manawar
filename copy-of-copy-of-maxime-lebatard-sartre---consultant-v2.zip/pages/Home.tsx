import React, { useRef, useState, useEffect } from 'react';
import { motion, useScroll, useTransform, useSpring, useMotionValue, useMotionTemplate } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Settings, Zap, Brain, ArrowDown, ChevronRight, CheckCircle2, Workflow } from 'lucide-react';
import Button from '../components/Button';
import { QUICK_SERVICES, KEY_STATS, EXPERIENCE_DATA, ACTION_IMAGE } from '../constants';

// --- ANIMATION UTILS ---

const letterContainerVariants = {
  hidden: { transition: { staggerChildren: 0.03 } },
  visible: { transition: { staggerChildren: 0.03 } }
};

const letterVariants = {
  hidden: { y: 20, opacity: 0, filter: "blur(5px)" },
  visible: { y: 0, opacity: 1, filter: "blur(0px)", transition: { duration: 0.4, ease: "easeOut" } }
};

// Component for Letter-by-Letter animation
const AnimatedTitle = ({ text, className }: { text: string; className?: string }) => {
    return (
        <motion.h1 
            className={className}
            variants={letterContainerVariants}
            initial="hidden"
            animate="visible"
        >
            {text.split("").map((char, i) => (
                <motion.span key={i} variants={letterVariants} className="inline-block">
                    {char === " " ? "\u00A0" : char}
                </motion.span>
            ))}
        </motion.h1>
    );
};

interface TiltCardProps {
  children: React.ReactNode;
  className?: string;
  disableTilt?: boolean;
}

const TiltCard: React.FC<TiltCardProps> = ({ children, className, disableTilt = false }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  
  // Smoother springs for Tilt
  const springConfig = { damping: 20, stiffness: 200, mass: 0.5 };
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [6, -6]), springConfig);
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-6, 6]), springConfig);

  // Parallax Scroll Effect on the card itself
  const { scrollY } = useScroll();
  const yParallax = useTransform(scrollY, [0, 500], [0, -50]); // Card floats up slightly on scroll

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    if (disableTilt) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    x.set(mouseX / width - 0.5);
    y.set(mouseY / height - 0.5);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      style={{ 
          rotateX: disableTilt ? 0 : rotateX, 
          rotateY: disableTilt ? 0 : rotateY, 
          y: yParallax,
          transformStyle: "preserve-3d" 
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`relative ${className}`}
    >
      {children}
    </motion.div>
  );
};

const Home: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Spotlight Effect Logic
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const handleSpotlightMove = ({ currentTarget, clientX, clientY }: React.MouseEvent) => {
    const { left, top } = currentTarget.getBoundingClientRect();
    mouseX.set(clientX - left);
    mouseY.set(clientY - top);
  };

  const spotlightBackground = useMotionTemplate`
    radial-gradient(
      600px circle at ${mouseX}px ${mouseY}px,
      rgba(37, 99, 235, 0.08),
      transparent 80%
    )
  `;

  // Parallax Text Reveal Refs
  const valueRef = useRef(null);
  const { scrollYProgress: valueScrollY } = useScroll({
    target: valueRef,
    offset: ["start end", "end start"]
  });
  
  const yText = useTransform(valueScrollY, [0, 1], [100, -100]);
  const opacityText = useTransform(valueScrollY, [0, 0.3, 0.8], [0, 1, 0]);

  // Image Parallax
  const { scrollY } = useScroll();
  const yImage = useTransform(scrollY, [0, 800], [0, 100]);
  const rotateCircle = useTransform(scrollY, [0, 1000], [0, 90]);
  const yCircle = useTransform(scrollY, [0, 1000], [0, 200]);

  return (
    <div ref={containerRef} className="bg-[#f5f5f5] text-black w-full overflow-hidden">
      
      {/* 1. HERO SECTION - Immersive & Alive */}
      <section 
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        onMouseMove={handleSpotlightMove}
      >
        {/* Dynamic Spotlight */}
        <motion.div 
            className="absolute inset-0 z-0 pointer-events-none opacity-100"
            style={{ background: spotlightBackground }}
        />

        {/* Animated Premium Background Blobs */}
        <div className="absolute inset-0 z-0 opacity-40 pointer-events-none">
            <div className="absolute top-[10%] left-[20%] w-[500px] h-[500px] bg-blue-300 rounded-full mix-blend-multiply filter blur-[80px] animate-blob"></div>
            <div className="absolute top-[20%] right-[20%] w-[500px] h-[500px] bg-purple-300 rounded-full mix-blend-multiply filter blur-[80px] animate-blob animation-delay-2000"></div>
            <div className="absolute -bottom-[10%] left-[40%] w-[600px] h-[600px] bg-pink-200 rounded-full mix-blend-multiply filter blur-[80px] animate-blob animation-delay-4000"></div>
        </div>

        {/* Right Side Geometric Shapes (Behind Image) */}
        <div className="absolute top-0 right-0 h-full w-1/2 z-0 pointer-events-none hidden lg:block overflow-visible">
             <motion.div 
                style={{ rotate: rotateCircle, y: yCircle }}
                className="absolute top-[15%] right-[-10%] w-[700px] h-[700px] border border-black/5 rounded-full border-dashed"
             />
             <motion.div 
                style={{ rotate: useTransform(scrollY, [0, 1000], [0, -60]), y: useTransform(scrollY, [0, 1000], [0, 100]) }}
                className="absolute top-[30%] right-[15%] w-[400px] h-[400px] border border-blue-500/10 rounded-full"
             />
        </div>


        <div className="relative z-10 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center w-full pt-10">
            <div className="lg:col-span-7 xl:col-span-8">
                <TiltCard className="perspective-1000">
                    <motion.div 
                        initial={{ opacity: 0, y: 50, rotateX: -5 }}
                        animate={{ opacity: 1, y: 0, rotateX: 0 }}
                        transition={{ duration: 1, ease: "easeOut" }}
                        className="bg-white/40 backdrop-blur-xl border border-white/60 p-10 md:p-16 rounded-[2.5rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] relative overflow-hidden group"
                    >
                        {/* Interactive Shine Effect on Card */}
                        <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>

                        <motion.span 
                            initial={{ opacity: 0, x: -10 }} 
                            animate={{ opacity: 1, x: 0 }} 
                            transition={{ delay: 0.5, duration: 0.8 }}
                            className="inline-flex items-center gap-2 px-3 py-1 mb-8 border border-black/5 bg-white/50 backdrop-blur-sm rounded-full text-xs font-semibold uppercase tracking-widest text-gray-500"
                        >
                            <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></span>
                            Consultant Digital & Opérations
                        </motion.span>
                        
                        <div className="mb-8">
                            <AnimatedTitle 
                                text="Optimisation." 
                                className="text-6xl md:text-8xl lg:text-[7rem] font-display font-bold leading-[0.85] tracking-tighter text-black mb-1" 
                            />
                        </div>

                        <motion.p 
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.8, duration: 0.8 }}
                            className="text-lg md:text-xl text-gray-700 max-w-lg leading-relaxed mb-12 font-light"
                        >
                            J’accompagne les entreprises dans l’amélioration de leurs processus, l’intégration d’outils modernes et la mise en place de solutions IA concrètes.
                        </motion.p>
                        
                        <motion.div 
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 1, duration: 0.8 }}
                            className="flex flex-wrap gap-4"
                        >
                            <Link to="/contact">
                                <Button size="lg" icon className="bg-black text-white shadow-xl shadow-blue-900/10">Demander un devis</Button>
                            </Link>
                            <Link to="/services">
                                <Button size="lg" variant="secondary" className="bg-white/80 hover:bg-white">Mes Services</Button>
                            </Link>
                        </motion.div>
                    </motion.div>
                </TiltCard>
            </div>
            
            {/* Visual Balance for Large Screens - The Action Image */}
            <div className="hidden lg:block lg:col-span-5 xl:col-span-4 relative h-full flex items-center justify-center pointer-events-none">
                 <motion.div 
                    style={{ y: yImage }}
                    initial={{ opacity: 0, scale: 0.9, rotate: 6 }}
                    animate={{ opacity: 1, scale: 1, rotate: 2 }}
                    transition={{ duration: 1.2, delay: 0.4, ease: "easeOut" }}
                    className="relative w-full max-w-[400px]"
                 >
                    {/* Floating Badge */}
                    <motion.div 
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 1.2, duration: 0.8 }}
                        className="absolute -top-6 -left-6 bg-white/90 backdrop-blur-md px-5 py-3 rounded-2xl shadow-xl border border-white/50 z-20 flex items-center gap-3 animate-bounce-slow"
                    >
                        <div className="bg-blue-100 p-2 rounded-xl">
                            <Workflow size={20} className="text-blue-600" />
                        </div>
                        <div>
                            <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Analyse</div>
                            <div className="text-sm font-bold text-black leading-none">Process Mapping</div>
                        </div>
                    </motion.div>

                    {/* Main Image Container */}
                    <div className="relative rounded-[2rem] overflow-hidden shadow-2xl border-4 border-white transform transition-transform duration-500 hover:rotate-0 hover:scale-[1.02]">
                        <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent z-10 opacity-60"></div>
                        <img 
                            src={ACTION_IMAGE} 
                            alt="Maxime Lebatard-Sartre - Optimisation Process" 
                            className="w-full h-auto object-cover"
                        />
                    </div>

                     {/* Second Floating Badge (Bottom) */}
                     <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 1.5, duration: 0.8 }}
                        className="absolute -bottom-8 -right-4 bg-white/90 backdrop-blur-md px-5 py-3 rounded-2xl shadow-xl border border-white/50 z-20 flex items-center gap-3"
                    >
                        <div className="bg-green-100 p-2 rounded-xl">
                            <CheckCircle2 size={20} className="text-green-600" />
                        </div>
                        <div>
                            <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Statut</div>
                            <div className="text-sm font-bold text-black leading-none">Ouvert aux projets</div>
                        </div>
                    </motion.div>
                 </motion.div>
            </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
            <span className="text-[10px] uppercase tracking-widest opacity-40">Scroll</span>
            <motion.div 
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
                <ArrowDown size={16} className="opacity-40" />
            </motion.div>
        </motion.div>
      </section>

      {/* 2. VALUE - "Parallax Text Reveal" */}
      <section ref={valueRef} className="min-h-[80vh] flex items-center relative overflow-hidden bg-white">
        <div className="absolute top-0 right-0 text-[20vw] font-bold text-gray-50 opacity-[0.03] leading-none pointer-events-none select-none font-display">
            IMPACT
        </div>
        <div className="max-w-7xl mx-auto px-6 relative z-10 w-full">
            <motion.div style={{ y: yText, opacity: opacityText }} className="max-w-4xl">
                <h2 className="text-4xl md:text-6xl font-display font-bold leading-tight mb-8">
                    J’aide les équipes à travailler <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">plus vite</span>, <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">mieux</span>, et avec moins de friction.
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-lg text-gray-500 font-light">
                    <p>J’analyse, simplifie et optimise vos processus internes. J’intègre des outils performants, j’automatise ce qui doit l’être, et je rends vos workflows plus fluides.</p>
                    <p>Mon approche combine IA, organisation, structuration et efficacité opérationnelle pour des résultats mesurables et durables.</p>
                </div>
            </motion.div>
        </div>
      </section>

      {/* 3. SERVICES - "Interactive Grid" */}
      <section className="py-32 bg-[#f5f5f5]">
        <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-6">
                <div>
                    <span className="text-blue-600 font-mono text-xs uppercase tracking-wider mb-2 block">01 — Expertise</span>
                    <h2 className="text-5xl font-display font-bold">Domaines d'intervention</h2>
                </div>
                <Link to="/services" className="group flex items-center gap-2 text-sm font-semibold border-b border-black pb-1 hover:text-blue-600 hover:border-blue-600 transition-all">
                    Tous les services <ChevronRight size={16} className="transition-transform group-hover:translate-x-1" />
                </Link>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {QUICK_SERVICES.map((service, index) => (
                    <TiltCard key={service.id} className="h-full" disableTilt={window.matchMedia("(pointer: coarse)").matches}>
                        <div className="relative h-full group rounded-3xl">
                            
                            {/* Animated Gradient Border (Behind) */}
                            <div className="absolute -inset-[2px] rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 overflow-hidden">
                                <motion.div
                                    className="absolute inset-[-50%] bg-[conic-gradient(from_0deg,transparent_0_340deg,#2563EB_360deg)]"
                                    animate={{ rotate: 360 }}
                                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                                />
                            </div>

                            {/* Main Card Content */}
                            <motion.div 
                                className="relative bg-white h-full p-10 rounded-3xl border border-gray-100 group-hover:border-transparent shadow-sm hover:shadow-2xl transition-all duration-300 overflow-hidden"
                                initial={{ opacity: 0, y: 50 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <div className="absolute top-0 right-0 p-10 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-700">
                                    {service.icon === 'Settings' && <Settings size={120} />}
                                    {service.icon === 'Zap' && <Zap size={120} />}
                                    {service.icon === 'Brain' && <Brain size={120} />}
                                </div>

                                <div className="relative z-10">
                                    <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center mb-8 text-black group-hover:bg-blue-600 group-hover:text-white transition-colors duration-300">
                                        {service.icon === 'Settings' && <Settings size={28} />}
                                        {service.icon === 'Zap' && <Zap size={28} />}
                                        {service.icon === 'Brain' && <Brain size={28} />}
                                    </div>
                                    <h3 className="text-2xl font-bold mb-4 font-display">{service.title}</h3>
                                    <p className="text-gray-600 leading-relaxed mb-8">{service.description}</p>
                                    <span className="inline-flex items-center text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300 text-blue-600">
                                        En savoir plus <ChevronRight size={12} className="ml-1" />
                                    </span>
                                </div>
                            </motion.div>
                        </div>
                    </TiltCard>
                ))}
            </div>
        </div>
      </section>

      {/* 4. EXPERIENCE - "Interactive Timeline" */}
      <section className="py-32 bg-white relative">
        <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                {/* Sticky Left Column */}
                <div className="lg:col-span-4 lg:sticky lg:top-32 h-fit">
                    <span className="text-blue-600 font-mono text-xs uppercase tracking-wider mb-2 block">02 — Parcours</span>
                    <h2 className="text-5xl font-display font-bold mb-8">Expérience<br/>Hybride</h2>
                    <p className="text-gray-500 mb-8 max-w-xs">
                        Une combinaison d'expériences corporate et terrain me permettant d’apporter une vision globale, technique et opérationnelle.
                    </p>
                    <Link to="/about">
                        <Button variant="outline" className="text-black border-black/20 hover:border-black">Voir le CV complet</Button>
                    </Link>
                </div>

                {/* Timeline Column */}
                <div className="lg:col-span-8 relative border-l border-gray-200 pl-8 md:pl-16 space-y-20">
                     {EXPERIENCE_DATA.slice(0, 3).map((exp, index) => (
                        <motion.div 
                            key={index}
                            initial={{ opacity: 0, x: 20 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ duration: 0.6 }}
                            className="relative group"
                        >
                            {/* Dot on timeline */}
                            <span className="absolute -left-[41px] md:-left-[73px] top-2 w-4 h-4 rounded-full border-2 border-white bg-gray-300 group-hover:bg-blue-600 group-hover:scale-125 transition-all duration-300 z-10 shadow"></span>
                            
                            <div className="bg-surface p-8 md:p-10 rounded-2xl hover:bg-gray-50 transition-colors duration-300">
                                <div className="flex flex-col md:flex-row md:items-baseline justify-between mb-4">
                                    <h3 className="text-2xl font-bold font-display">{exp.company}</h3>
                                    <span className="text-sm font-mono text-gray-500">{exp.period}</span>
                                </div>
                                <div className="text-blue-600 font-medium mb-4">{exp.role}</div>
                                <p className="text-gray-600 mb-6">{exp.description}</p>
                                {exp.missions && (
                                    <ul className="space-y-2">
                                        {exp.missions.slice(0,2).map((m, i) => (
                                            <li key={i} className="flex items-start gap-2 text-sm text-gray-500">
                                                <CheckCircle2 size={16} className="text-blue-600 shrink-0 mt-0.5" />
                                                <span>{m}</span>
                                            </li>
                                        ))}
                                    </ul>
                                )}
                            </div>
                        </motion.div>
                     ))}
                </div>
            </div>
        </div>
      </section>

      {/* 5. STATS - "Count Up & Clean" */}
      <section className="py-24 bg-black text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-noise opacity-10"></div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center md:text-left">
                {KEY_STATS.map((stat, idx) => (
                    <motion.div 
                        key={idx}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: idx * 0.1 }}
                        className="space-y-2"
                    >
                        <div className="text-4xl md:text-6xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-500">
                            {stat.value}
                        </div>
                        <div className="text-sm text-gray-400 font-medium tracking-wide">{stat.label}</div>
                    </motion.div>
                ))}
            </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="py-40 bg-white text-center">
        <div className="max-w-4xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", duration: 0.8 }}
          >
              <h2 className="text-5xl md:text-7xl font-display font-bold mb-10 tracking-tight">
                Prêt à passer au <br/> niveau supérieur ?
              </h2>
              <Link to="/contact">
                <Button size="lg" className="text-lg px-12 py-6 bg-black text-white hover:bg-neutral-800">
                  Me contacter
                </Button>
              </Link>
          </motion.div>
        </div>
      </section>

    </div>
  );
};

export default Home;