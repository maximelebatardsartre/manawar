import React from 'react';
import { Linkedin, Mail } from 'lucide-react';
import { CONTACT_INFO, NAVIGATION_LINKS } from '../constants';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-950 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16">
          
          {/* Brand */}
          <div className="space-y-6">
            <div className="text-3xl font-display font-bold">
              Maxime<br/>Lebatard-Sartre<span className="text-blue-500">.</span>
            </div>
            <p className="text-gray-400 max-w-xs text-sm leading-relaxed">
              Optimisation, Automatisation & Intelligence Artificielle.
              Transformer les opérations pour plus d'efficacité.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Navigation</h4>
            <ul className="space-y-4">
              {NAVIGATION_LINKS.map((link) => (
                <li key={link.path}>
                  <Link to={link.path} className="text-gray-400 hover:text-white transition-colors text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact</h4>
            <div className="flex flex-col gap-4">
              <a href={`mailto:${CONTACT_INFO.email}`} className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors group">
                <div className="p-2 bg-white/5 rounded-full group-hover:bg-white/10">
                    <Mail size={18} />
                </div>
                <span className="text-sm">{CONTACT_INFO.email}</span>
              </a>
              <a href={CONTACT_INFO.linkedin} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-gray-400 hover:text-white transition-colors group">
                <div className="p-2 bg-white/5 rounded-full group-hover:bg-white/10">
                    <Linkedin size={18} />
                </div>
                <span className="text-sm">LinkedIn Profile</span>
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-gray-500">© 2026 Maxime Lebatard-Sartre - Tous droits réservés.</p>
          <div className="flex gap-6 text-xs text-gray-500">
            <span className="cursor-pointer hover:text-white">Mentions légales</span>
            <span className="cursor-pointer hover:text-white">Politique de confidentialité</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;