import React from 'react';
import { motion } from 'framer-motion';

interface AnimatedLogoProps {
  scrolled?: boolean;
}

const AnimatedLogo: React.FC<AnimatedLogoProps> = ({ scrolled = false }) => {
  // Variants for the construction animation (Load)
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.5, // Start after page load slightly
      },
    },
  };

  // Left Pillar - Appears from top
  const leftPillarVariants = {
    hidden: { pathLength: 0, opacity: 0, y: -20 },
    visible: { 
      pathLength: 1, 
      opacity: 1, 
      y: 0,
      transition: { duration: 1.5, ease: [0.16, 1, 0.3, 1] } 
    },
    hover: { y: -3, transition: { duration: 0.3 } }
  };

  // Right Pillar - Appears from bottom
  const rightPillarVariants = {
    hidden: { pathLength: 0, opacity: 0, y: 20 },
    visible: { 
      pathLength: 1, 
      opacity: 1, 
      y: 0,
      transition: { duration: 1.5, ease: [0.16, 1, 0.3, 1] } 
    },
    hover: { y: -3, transition: { duration: 0.3 } }
  };

  // Middle Connector (The System) - Connects them
  const connectorVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: { 
      pathLength: 1, 
      opacity: 1, 
      transition: { duration: 1.2, ease: "easeInOut", delay: 0.5 } 
    },
    hover: { 
      scale: 1.05,
      originX: "50%",
      originY: "50%",
      transition: { duration: 0.4 } 
    }
  };

  // The AI Dot (Blue Point) - Final touch
  const dotVariants = {
    hidden: { scale: 0, opacity: 0 },
    visible: { 
      scale: 1, 
      opacity: 1,
      transition: { 
        type: "spring", 
        stiffness: 300, 
        damping: 15, 
        delay: 1.2 
      } 
    },
    hover: { 
      scale: 1.3,
      filter: "drop-shadow(0 0 6px rgba(37, 99, 235, 0.6))",
      transition: { duration: 0.3 }
    }
  };

  return (
    <motion.div
      className="flex items-center gap-4 select-none"
      initial="hidden"
      animate="visible"
      whileHover="hover"
      variants={containerVariants}
    >
      {/* The Graphic Symbol */}
      <motion.svg
        animate={{ 
            width: scrolled ? 32 : 48,
            height: scrolled ? 32 : 48
        }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        viewBox="0 0 50 50"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="text-black"
      >
        {/* Left Pillar */}
        <motion.path
          d="M12 10V40"
          stroke="currentColor"
          strokeWidth="5"
          strokeLinecap="round"
          variants={leftPillarVariants}
        />
        
        {/* Right Pillar */}
        <motion.path
          d="M38 10V40"
          stroke="currentColor"
          strokeWidth="5"
          strokeLinecap="round"
          variants={rightPillarVariants}
        />

        {/* Middle Connector (Data Flow) */}
        <motion.path
          d="M12 18L25 30L38 18"
          stroke="currentColor"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
          variants={connectorVariants}
        />

        {/* The AI/Optimization Dot */}
        <motion.circle
          cx="44"
          cy="42"
          r="3.5"
          className="fill-blue-600"
          variants={dotVariants}
        />
      </motion.svg>

      {/* Text Part */}
      <div className="flex flex-col justify-center">
        <motion.span 
            className="font-display font-bold leading-none tracking-tight"
            initial={{ opacity: 0, x: -20 }}
            animate={{ 
                opacity: 1, 
                x: 0,
                fontSize: scrolled ? '1.25rem' : '1.75rem', // 20px vs 28px
            }}
            transition={{ 
                opacity: { delay: 1.5, duration: 0.8 },
                x: { delay: 1.5, duration: 0.8, type: "spring" },
                fontSize: { duration: 0.6, ease: [0.16, 1, 0.3, 1] }
            }}
        >
          MLS
        </motion.span>
      </div>
    </motion.div>
  );
};

export default AnimatedLogo;