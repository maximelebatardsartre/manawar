import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { NAVIGATION_LINKS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';
import AnimatedLogo from './AnimatedLogo';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ease-[0.16,1,0.3,1] ${
        scrolled ? 'py-4' : 'py-10'
      }`}
    >
      {/* Dynamic Background for Scrolled State */}
      <div 
        className={`absolute inset-0 bg-white/80 backdrop-blur-xl border-b border-white/20 transition-opacity duration-700 ${
            scrolled ? 'opacity-100' : 'opacity-0'
        }`} 
      />

      <div className="relative max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Animated Logo */}
        <Link to="/" className="z-50" data-cursor-hover>
          <AnimatedLogo scrolled={scrolled} />
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-10">
          {NAVIGATION_LINKS.map((link) => (
            <Link 
              key={link.path} 
              to={link.path}
              data-cursor-hover
              className={`text-sm font-medium transition-colors hover:text-black relative group ${
                location.pathname === link.path ? 'text-black' : 'text-gray-500'
              }`}
            >
              {link.label}
              <span className={`absolute -bottom-1 left-0 w-0 h-px bg-black transition-all duration-300 group-hover:w-full ${location.pathname === link.path ? 'w-full' : ''}`}></span>
            </Link>
          ))}
          <Link to="/contact">
            <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-2.5 bg-black text-white text-xs font-semibold rounded-full hover:bg-neutral-800 transition-colors"
                data-cursor-hover
            >
              Me contacter
            </motion.button>
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-black p-2 z-50 relative"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Toggle menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
            <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="md:hidden absolute top-0 left-0 right-0 min-h-screen bg-white flex flex-col items-center justify-center gap-8 p-6 z-40"
            >
                {NAVIGATION_LINKS.map((link) => (
                    <Link 
                        key={link.path} 
                        to={link.path}
                        className="text-3xl font-display font-bold text-black"
                    >
                        {link.label}
                    </Link>
                ))}
                <Link to="/contact" className="mt-8">
                    <button className="px-8 py-4 bg-black text-white font-semibold rounded-full text-lg">
                        Me contacter
                    </button>
                </Link>
            </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;