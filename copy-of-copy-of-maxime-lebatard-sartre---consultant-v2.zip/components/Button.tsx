import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'glass';
  size?: 'sm' | 'md' | 'lg';
  icon?: boolean;
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  size = 'md',
  icon = false, 
  className = '', 
  ...props 
}) => {
  const ref = useRef<HTMLButtonElement>(null);
  
  // Motion values for the internal fill effect
  const xFill = useMotionValue(0);
  const yFill = useMotionValue(0);

  // Motion values for the MAGNETIC effect (whole button movement)
  const xButton = useMotionValue(0);
  const yButton = useMotionValue(0);

  // Springs for smooth magnetic movement
  const springConfig = { damping: 15, stiffness: 150, mass: 0.1 };
  const xButtonSpring = useSpring(xButton, springConfig);
  const yButtonSpring = useSpring(yButton, springConfig);

  const top = useTransform(yFill, [-0.5, 0.5], ["40%", "60%"]);
  const left = useTransform(xFill, [-0.5, 0.5], ["60%", "70%"]);

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    const rect = ref.current!.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    // Fill effect calculation
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    xFill.set(xPct);
    yFill.set(yPct);

    // Magnetic effect calculation (max movement +/- 10px)
    const moveX = (mouseX - width / 2) * 0.2;
    const moveY = (mouseY - height / 2) * 0.2;
    xButton.set(moveX);
    yButton.set(moveY);
  };

  const handleMouseLeave = () => {
    xFill.set(0);
    yFill.set(0);
    xButton.set(0);
    yButton.set(0);
  };

  const sizeStyles = {
    sm: "px-6 py-3 text-xs",
    md: "px-8 py-4 text-sm",
    lg: "px-10 py-5 text-base"
  };

  const baseStyles = "relative overflow-hidden inline-flex items-center justify-center gap-2 font-medium transition-colors duration-300 rounded-full tracking-wide z-10 group";
  
  const variants = {
    primary: "bg-black text-white hover:text-white shadow-lg hover:shadow-xl",
    secondary: "bg-white text-black border border-gray-200 hover:border-black shadow-sm",
    outline: "bg-transparent text-white border border-white/30 hover:border-white",
    glass: "bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20"
  };

  return (
    <motion.button 
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      initial={{ scale: 1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      style={{ x: xButtonSpring, y: yButtonSpring }}
      className={`${baseStyles} ${sizeStyles[size]} ${variants[variant]} ${className}`}
      {...props}
      data-cursor-hover 
    >
      <span className="relative z-10 flex items-center gap-2">
        {children}
        {icon && <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />}
      </span>
      
      {/* Magnetic fill effect on hover */}
      {variant === 'primary' && (
        <motion.div 
            style={{ top, left, x: "-50%", y: "-50%" }}
            className="absolute w-[150%] h-[150%] rounded-full bg-neutral-800 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-0 pointer-events-none blur-xl"
        />
      )}
    </motion.button>
  );
};

export default Button;